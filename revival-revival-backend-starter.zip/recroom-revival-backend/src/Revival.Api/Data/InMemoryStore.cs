using System.Collections.Concurrent;

namespace Revival.Api;

public sealed record User(Guid Id, string DisplayName, DateTimeOffset CreatedAt);
public sealed record Session(string Token, Guid UserId, DateTimeOffset ExpiresAt);
public sealed record World(Guid Id, string Name, string Description, Guid OwnerId, bool Published);
public sealed record InventoryItem(Guid Id, Guid UserId, string DefinitionId, int Quantity);

public sealed class InMemoryStore
{
    public ConcurrentDictionary<Guid, User> Users { get; } = new();
    public ConcurrentDictionary<string, Session> Sessions { get; } = new();
    public ConcurrentDictionary<Guid, World> Worlds { get; } = new();
    public ConcurrentDictionary<Guid, InventoryItem> Inventory { get; } = new();
}
