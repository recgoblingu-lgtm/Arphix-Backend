using Microsoft.AspNetCore.Http.Json;
using Revival.Api;
using Revival.Api.Modules;
using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);
builder.Services.Configure<JsonOptions>(options => options.SerializerOptions.Converters.Add(new JsonStringEnumConverter()));
builder.Services.AddSingleton<InMemoryStore>();
builder.Services.AddSingleton<SessionService>();

var app = builder.Build();
app.MapGet("/health", () => Results.Ok(new { status = "ok", service = "revival-api", utc = DateTimeOffset.UtcNow }));
app.MapAuthEndpoints();
app.MapSocialEndpoints();
app.MapWorldEndpoints();
app.MapInventoryEndpoints();
app.Run();

public partial class Program { }
