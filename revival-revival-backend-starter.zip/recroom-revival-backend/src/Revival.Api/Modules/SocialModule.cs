using Revival.Api;

namespace Revival.Api.Modules;

public static class SocialModule
{
    public static void MapSocialEndpoints(this IEndpointRouteBuilder app)
    {
        app.MapGet("/v1/social/players", (string? q, InMemoryStore store) => Results.Ok(store.Users.Values.Where(u => string.IsNullOrWhiteSpace(q) || u.DisplayName.Contains(q, StringComparison.OrdinalIgnoreCase))));
        app.MapGet("/v1/presence", () => Results.Ok(Array.Empty<object>()));
        app.MapGet("/v1/parties/{partyId:guid}", (Guid partyId) => Results.NotFound(new { error = "party system not initialized", partyId }));
    }
}
