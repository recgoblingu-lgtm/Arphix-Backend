using Revival.Api;

namespace Revival.Api.Modules;

public static class WorldModule
{
    public static void MapWorldEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/v1/worlds");
        group.MapGet("/", (InMemoryStore store) => Results.Ok(store.Worlds.Values.Where(w => w.Published)));
        group.MapPost("/", (CreateWorldRequest request, HttpContext http, InMemoryStore store, SessionService sessions) =>
        {
            var user = sessions.GetUser(http, store); if (user is null) return Results.Unauthorized();
            var world = new World(Guid.NewGuid(), request.Name.Trim(), request.Description?.Trim() ?? "", user.Id, request.Published);
            store.Worlds[world.Id] = world; return Results.Created($"/v1/worlds/{world.Id}", world);
        });
        group.MapGet("/{id:guid}", (Guid id, InMemoryStore store) => store.Worlds.TryGetValue(id, out var world) ? Results.Ok(world) : Results.NotFound());
    }
}
public sealed record CreateWorldRequest(string Name, string? Description, bool Published = false);
