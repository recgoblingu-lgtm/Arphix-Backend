using Revival.Api;

namespace Revival.Api.Modules;

public sealed class SessionService(InMemoryStore store)
{
    public Session Create(User user)
    {
        var session = new Session(Convert.ToBase64String(Guid.NewGuid().ToByteArray()), user.Id, DateTimeOffset.UtcNow.AddDays(7));
        store.Sessions[session.Token] = session;
        return session;
    }

    public User? GetUser(HttpContext context, InMemoryStore data)
    {
        var header = context.Request.Headers.Authorization.ToString();
        if (!header.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase)) return null;
        var token = header[7..];
        return data.Sessions.TryGetValue(token, out var session) && session.ExpiresAt > DateTimeOffset.UtcNow && data.Users.TryGetValue(session.UserId, out var user) ? user : null;
    }
}
