using Revival.Api;

namespace Revival.Api.Modules;

public static class AuthModule
{
    public static void MapAuthEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/v1/auth");
        group.MapPost("/register", (RegisterRequest request, InMemoryStore store, SessionService sessions) =>
        {
            if (string.IsNullOrWhiteSpace(request.DisplayName)) return Results.BadRequest(new { error = "displayName is required" });
            var user = new User(Guid.NewGuid(), request.DisplayName.Trim(), DateTimeOffset.UtcNow);
            store.Users[user.Id] = user;
            return Results.Ok(sessions.Create(user));
        });
        group.MapPost("/login", (LoginRequest request, InMemoryStore store, SessionService sessions) =>
        {
            var user = store.Users.Values.FirstOrDefault(x => x.DisplayName.Equals(request.DisplayName.Trim(), StringComparison.OrdinalIgnoreCase));
            return user is null ? Results.Unauthorized() : Results.Ok(sessions.Create(user));
        });
        group.MapGet("/me", (HttpContext http, InMemoryStore store, SessionService sessions) =>
        {
            var user = sessions.GetUser(http, store);
            return user is null ? Results.Unauthorized() : Results.Ok(user);
        });
    }
}

public sealed record RegisterRequest(string DisplayName);
public sealed record LoginRequest(string DisplayName);
