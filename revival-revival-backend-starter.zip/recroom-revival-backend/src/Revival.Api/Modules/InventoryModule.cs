using Revival.Api;

namespace Revival.Api.Modules;

public static class InventoryModule
{
    public static void MapInventoryEndpoints(this IEndpointRouteBuilder app)
    {
        app.MapGet("/v1/inventory", (HttpContext http, InMemoryStore store, SessionService sessions) =>
        {
            var user = sessions.GetUser(http, store); if (user is null) return Results.Unauthorized();
            return Results.Ok(store.Inventory.Values.Where(x => x.UserId == user.Id));
        });
    }
}
